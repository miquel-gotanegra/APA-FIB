Práctica realizada con Python 3.11.1

Todas las librerías necesarias se pueden instalar descomentando el primer bloque de código del notebook.

Para ejecutar el código hemos usado un jupyter-notebook, pero también se puede ejecutar abriéndolo en un google-colab

Adjuntamos tambien nuestro conjunto de datos en formato csv, por si hay algun problema con el repositorio en un futuro